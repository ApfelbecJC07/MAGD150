new p5();

//global array data
let array1 = [100, 200, 300, 400, 500];
let arr1size = 5;

let array2 = [];
let arr2size = 0;
for(let i = 0; i < 4; i++){
  let x = random(array1);
  append(array2, x);
  arr2size++;
}

function setup() {
  createCanvas(600, 600);
  
  //print sizes
  print('Array 1: ', array1);
  print('Size of array 1:', arr1size);
  print('Array 2: ', array2);
  print('Size of array 2:', arr2size);
}

function draw() {
  background(220);
  fill('red');
  circle(array1[2], array1[2], 100);
  fill('blue'); 
  rect(array2[0], array2[1], array2[2], array2[3]);
  noLoop();
}

function mouseClicked(){
  let array3 = [mouseX, mouseY];
  fill('green');
  triangle(array3[0], array3[1], array3[0]-40, array3[1]+40, array3[0]+40, array3[1]+40);
  return false;
}