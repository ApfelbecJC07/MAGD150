function setup() {
  createCanvas(400, 400);
  background(220);
  angleMode(DEGREES);
}

function stickMan(x,y){
  push();
  strokeWeight(1);
  stroke(0);
  fill(255);
  ellipse(x,y,30,30); //head
  line(x,y+15,x,y+60); //body
  line(x,y+35,x-10,y+30); //left arm
  line(x,y+35,x+10,y+30); //right arm
  line(x,y+60,x-10,y+70); //left leg
  line(x,y+60,x+10,y+70);
  pop();
}

function draw() {
  stickMan(200,150);
  
  //FUNCTION WITH TRANSLATION
  translate(50,20);
  stickMan(200,150);
  translate(-25,-10);
  
  //FUNCTION WITH FOR LOOP
  for(let i=0; i<399; i+=50){
    stickMan(i,300);
  }
  
  translate(-25,-10); //reset translation coords
  
  //FUNCTION SCALE 
  scale(2);
  stickMan(50,50);
  scale(0.25);
  stickMan(350,50);
  scale(2); //reset scale
  
  //ROTATE FUNCTION
  rotate(135);
  stickMan(-100,-350);
  rotate(225); //reset angle
  stickMan(50,50);
  
  //PRINT TO CONSOLE
  noLoop();
  print("14 stick men drawn");
}