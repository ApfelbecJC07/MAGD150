let cloud, sora;
function preload() {
  cloud = loadImage('https://upload.wikimedia.org/wikipedia/en/c/c7/Cloudac1.jpg');
  sora = loadImage('https://upload.wikimedia.org/wikipedia/en/9/99/Sora.png');
}

function setup() {
  createCanvas(750, 750);
  background(220);
}

function draw(){
  background(220);
  
  //IMAGES
  image(cloud, mouseX,mouseY); //jpg moves with mouse position
  image(sora, mouseX+300,mouseY+100); //transparent png 400,150
  
  //TEXT
  textSize(20);
  textFont('Georgia');
  stroke(20);
  
  fill('blue');
  text('Cloud - Final Fantasy VII', mouseX, mouseY+325);
  
  fill('green');
  text('Sora - Kingdom Hearts', mouseX+300,mouseY+475); //400, 550
  
  fill(0);
  let wrappedText = 'These are characters from Square Enix games.';
  text(wrappedText, 50,475,200,525);
}